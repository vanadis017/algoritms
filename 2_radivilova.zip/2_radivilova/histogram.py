import sys


def histogram(list1, k):
    if not list1 or k <= 0:
        return []

    min1 = min(list1)
    max1 = max(list1)

    # Шаг интервала
    step = (max1 - min1) / k

    # Чтобы последний интервал включал max_val
    list2 = [0] * k
    for i in list1:
        if i == max1:
            list2[-1] += 1
        else:
            ind = int((i - min1) / step)
            list2[ind] += 1
    return list2


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(1)
    list3 = [int(x) for x in sys.argv[1].split(',')]
    k = int(sys.argv[2])

    res = histogram(list3, k)
    print(res)