

import sys

def parse_matrix(arg):
    if not arg:
        return None
    rows = arg.split(',')
    matrix = []
    try:
        for row in rows:
            numbers = [float(x) for x in row.split()]
            if not numbers:
                return None
            matrix.append(numbers)
    except:
        return None

    # Проверяем, что все строки одинаковой длины
    row_len = len(matrix[0])
    for row in matrix:
        if len(row) != row_len:
            return None

    return matrix


def matrix_multiply(a, b):
    if len(a[0]) != len(b):
        raise ValueError

    result = []
    for i in range(len(a)):
        new_row = []
        for j in range(len(b[0])):
            value = 0.0
            for k in range(len(b)):
                value += a[i][k] * b[k][j]
            new_row.append(value)
        result.append(new_row)
    return result


def main():
    arguments = sys.argv[1:]

    if not arguments:
        print("Invalid input")
        return

    matrices = []

    for arg in arguments:
        matrix = parse_matrix(arg)
        if matrix is None:
            print("Invalid input")
            return
        matrices.append(matrix)

    result = matrices[0]

    try:
        for m in matrices[1:]:
            result = matrix_multiply(result, m)
    except:
        print("Incompatible size of matrices")
        return

    print(result)


if __name__ == "__main__":
    main()