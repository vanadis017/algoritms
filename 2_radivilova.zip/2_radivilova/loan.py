import sys

def main():
    arguments = sys.argv[1:]

    if len(arguments) != 3:
        print("Invalid input")
        return

    try:
        amount = float(arguments[0])
        rate = float(arguments[1])
        months = int(arguments[2])

        if amount <= 0 or rate < 0 or months <= 0:
            print("Invalid input")
            return
    except:
        print("Invalid input")
        return

    stav = rate / 12

    if stav == 0:
        pmt = amount / months
    else:
        pmt = amount * (stav * (1 + stav) ** months) / ((1 + stav) ** months - 1)

    balance = amount
    res = []

    for _ in range(months):
        interest = balance * stav
        principal = pmt - interest

        pmt_1 = round(pmt, 2)
        principal_1 = round(principal, 2)
        interest_1 = round(interest, 2)

        res.append([pmt_1, principal_1, interest_1])

        balance -= principal

    print(res)


if __name__ == "__main__":
    main()