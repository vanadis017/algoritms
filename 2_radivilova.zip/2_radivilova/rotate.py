import sys
list = sys.argv[1]
k = int(sys.argv[2])

if "." in list:
    lst = [float(x) for x in list.split(",")]
else:
    lst = [int(x) for x in list.split(",")]
if lst:
    k %= len(lst)
    lst = lst[-k:] + lst[:-k]
print(lst)