import sys
list1=sys.argv[1]
list2=[int(x) for x in list1.split(',')]
k=int(sys.argv[2])

elements=len(list2)

sredn_arifm=sum(list2)/elements

sigma=(sum((x-sredn_arifm)**2 for x in list2)/elements)**0.5

l_bound=sredn_arifm-k*sigma
u_bound=sredn_arifm+k*sigma

anomalies=[x for x in list2 if x<l_bound or x>u_bound]
print(anomalies)