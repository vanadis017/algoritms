import sys
def main():
    arguments=sys.argv[1:]
    if len(arguments)!=1:
        print("Invalid input")
        return

    try:
        int_arguments=int(arguments[0])
        if int_arguments%2==0 or int_arguments<=0:
            print("Invalid input")
            return
    except:
        print("Invalid input")
        return

    n = int_arguments
    sq=[[0]*n for i in range(n)]
    x, y=0, n//2  # стартовая позиция

    for j in range(1 , n*n + 1):
        # используем террасный метод (сдвиг по формуле)
        sq[x][y] = ((j-1 + n//2) % n) * n + ((j-1) // n + n//2) % n + 1
        # движение по диагонали вверх-вправо
        ni, nj = (x-1)%n, (y+1)%n
        if sq[ni][nj]:
            x = (x+1)%n
        else:
            x, y = ni, nj
    print(sq)

if __name__=="__main__":
    main()