import sys
n=int(sys.argv[1])

if n<2:
    sys.exit(0)

true=[True]*(n+1)

true[0]=False
true[1]=False

prostoe_chislo=2

while prostoe_chislo*prostoe_chislo<=n:
    if true[prostoe_chislo]:
        for i in range(prostoe_chislo*prostoe_chislo, n+1, prostoe_chislo):
            true[i]=False
    prostoe_chislo+=1

is_true=[x for x in range(2,n+1) if true[x]]
print(is_true)




