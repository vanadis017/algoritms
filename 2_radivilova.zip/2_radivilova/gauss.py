import sys

def matrix(x):
    try:
        numb = x.split(',')
        matrix1 = []
        for j in numb:
            elements = [float(i) for i in j.strip().split()]
            matrix1.append(elements)
        return matrix1
    except:
        return None

def spi_matrix(x):
    try:
        return [float(i) for i in x.strip().split()]
    except:
        return None

def gauss(a, b):
    len_a = len(a)
    len_a0 = len(a[0])
    m = len_a0
    shir_matrix = [a[i][:] + [b[i]] for i in range(len_a)]

    # Прямой ход
    for q in range(min(len_a, len_a0)):
        row = max(range(q, len_a), key=lambda r: abs(shir_matrix[r][q]))
        if abs(shir_matrix[row][q]) < 1e-10:
            continue
        shir_matrix[q], shir_matrix[row] = shir_matrix[row], shir_matrix[q]
        pivot = shir_matrix[q][q]
        shir_matrix[q] = [x / pivot for x in shir_matrix[q]]
        for r in range(q + 1, len_a):
            factor = shir_matrix[r][q]
            shir_matrix[r] = [shir_matrix[r][i] - factor * shir_matrix[q][i] for i in range(m + 1)]

    # Обратный ход
    x = [0] * m
    for i in reversed(range(len_a)):
        row = shir_matrix[i]
        pivot_col = -1
        for j in range(len_a0):
            if abs(row[j]) > 1e-10:
                pivot_col = j
                break
        if pivot_col == -1:
            if abs(row[-1]) > 1e-10:
                return "No solution"
            else:
                continue
        sum_ax = sum(row[j] * x[j] for j in range(pivot_col + 1, len_a0))
        x[pivot_col] = row[-1] - sum_ax

    rank = sum(any(abs(c) > 1e-10 for c in row[:-1]) for row in shir_matrix)
    if rank < len_a0:
        return "Parametric solution"

    # Возвращаем целые числа
    return [int(round(val)) for val in x]

def main():
    arguments = sys.argv[1:]
    if len(arguments) != 2:
        print("Invalid input")
        return

    a = matrix(arguments[0])
    b = spi_matrix(arguments[1])
    if a is None or b is None:
        print("Invalid input")
        return

    len_a = len(a)
    if len_a == 0 or len(b) != len_a:
        print("Incompatible size of matrices")
        return
    len_a0 = len(a[0])
    for row in a:
        if len(row) != len_a0:
            print("Incompatible size of matrices")
            return

    res = gauss(a, b)
    print(res)

if __name__ == "__main__":
    main()